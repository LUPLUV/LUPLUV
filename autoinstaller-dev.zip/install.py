import json
import os
import ctypes, sys

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if not is_admin():\
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
else:
    f = open("soft.json")
    
    data = json.load(f)
    
    buckets = []
    
    for bucket in data["scoop"]["buckets"]:
        buckets+=[bucket]
        os.system("scoop bucket add "+bucket)
    
    for bucket in data["scoop"]["custom-buckets"]:
        buckets+=["ext/"+bucket["name"]]
        
    pendingCommands = []
    
    for app in data["scoop"]["apps"]:
        if(app["bucket"] in buckets):
            print("Do you want to install "+app["name"]+"? (y/n)")
            an = input()
            if(an == "y"):
                v = ""
                if(app["version"] != "latest"): v = "@"+app["version"]
                pendingCommands+="scoop install "+app["name"]+v
        else:
            print("Couldnt install "+app["name"]+" on version "+app["version"]+" because bucket is not available!")
    
    f.close()
    
    for command in pendingCommands:
        os.system(command)